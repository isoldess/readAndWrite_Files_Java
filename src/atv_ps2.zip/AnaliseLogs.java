import java.io.IOException;
import java.util.List;

public class AnaliseLogs{
    public static void main(String[] args) throws IOException {
        ManipuladorArquivo Analise = new ManipuladorArquivo();
        String pathEntrada = "src\\access_exemplo.log";
        String pathSaida = "src\\relatorio.txt";

        List<String> campos = Analise.leitor(pathEntrada);
        Analise.escrever(pathSaida, campos);

        System.out.println("Relatorio gerado em: " + pathSaida);
    }
}