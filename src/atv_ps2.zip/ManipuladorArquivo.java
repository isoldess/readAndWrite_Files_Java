import java.util.ArrayList;
import java.util.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ManipuladorArquivo{

    public List<String> leitor(String path) throws IOException{
        String linha = "";
        List<String> Campos = new ArrayList<>();
        try{
            BufferedReader buffRead = new BufferedReader(new FileReader(path));
            while ((linha = buffRead.readLine()) != null){
            Campos.add(linha);
            }
            buffRead.close();
        }
        catch (FileNotFoundException e){
            System.out.println("Erro,o arquivo não foi encontrado!");
        }
        return Campos;
    }
    

    public static void escritor(String path) throws IOException{
        BufferedWriter buffWrite = new BufferedWriter(new FileWriter(path));
        String linha = "";
        Scanner in = new Scanner(System.in);
        System.out.println("RELATORIO DE ANALISE DO SERVIDOR\r\n" + //
                        "  ================================\r\n" + //
                        "  Registros validos processados: 6\r\n" + //
                        "  Requisicoes com falha: 3\r\n" + //
                        "\r\n" + //
                        "  FALHAS ENCONTRADAS\r\n" + //
                        "  2026-03-17 14:04 | POST | /api/v1/payments | 500 | 360ms\r\n" + //
                        "  2026-03-17 14:06 | GET | /api/v1/orders | 404 | 95ms\r\n" + //
                        "  2026-03-17 14:10 | DELETE | /api/v1/users/8 | 403 | 120ms\r\n" + //
                        "\r\n" + //
                        "  TEMPO MEDIO - /api/v1/payments\r\n" + //
                        "  260.00ms");
        linha = in.nextLine();
        buffWrite.append(linha + "\n");
        buffWrite.close();
        in.close();
    }

    /**
     * Monta o relatorio de analise do servidor a partir das linhas de log
     * (usando o AnalisadorLog) e grava o resultado em um arquivo .txt
     * no formato do relatorio de exemplo.
     *
     * @param path   caminho do arquivo .txt de saida
     * @param campos linhas de log ja lidas (ex: retorno de leitor())
     */
    public void escrever(String path, List<String> campos) throws IOException {
        IAnalisadorLog analisador = new AnalisadorLog();

        int registrosValidos = analisador.contarRegistrosValidos(campos);
        List<String> falhas = analisador.listarRequisicoesComFalha(campos);
        double tempoMedioPayments = analisador.calcularTempoMedioPayments(campos);

        try (BufferedWriter buffWrite = new BufferedWriter(new FileWriter(path))) {
            buffWrite.write("RELATORIO DE ANALISE DO SERVIDOR\n");
            buffWrite.write("  ================================\n");
            buffWrite.write("  Registros validos processados: " + registrosValidos + "\n");
            buffWrite.write("  Requisicoes com falha: " + falhas.size() + "\n");
            buffWrite.write("\n");
            buffWrite.write("  FALHAS ENCONTRADAS\n");
            for (String falha : falhas) {
                buffWrite.write("  " + falha + "\n");
            }
            buffWrite.write("\n");
            buffWrite.write("  TEMPO MEDIO - /api/v1/payments\n");
            buffWrite.write("  " + String.format("%.2f", tempoMedioPayments) + "ms\n");
        }
    }
}