import java.util.ArrayList;
import java.util.List;

public class AnalisadorLog implements IAnalisadorLog {


    
    @Override
    public int contarRegistrosValidos(List<String> campos) {
    int registrosValidos = 0;

    for (int i = 0; i < campos.size(); i++) {
        String[] camposLinha = campos.get(i).split("\\|");
        boolean hasMS = camposLinha.length > 5 && camposLinha[5].contains("ms");

        if (camposLinha.length == 6 && !camposLinha[5].equals("null") && hasMS) {
            registrosValidos++;
        }
    }
    return registrosValidos;
}

    @Override
    public List<String> listarRequisicoesComFalha(List<String> campos) {
        List<String> falhas = new ArrayList<>();
        for (int i = 0; i < campos.size(); i++) {
        String[] camposLinha = campos.get(i).split("\\|");
        boolean hasMS = camposLinha.length > 5 && camposLinha[5].contains("ms");

        if (camposLinha.length != 6 || camposLinha[5].equals("null") || !hasMS) {
            falhas.add(campos.get(i));
            continue;
        }

        try {
            if (Integer.parseInt(camposLinha[4].trim()) >= 400) {
                falhas.add(campos.get(i));
            }
        } catch (NumberFormatException e) {
            falhas.add(campos.get(i));
        }}
        return falhas;
    }

    
   public double calcularTempoMedioPayments(List<String> campos) {
    int cont = 0;
    int tempoTotal = 0;

    for (int i = 0; i < campos.size(); i++) {
        String[] camposLinha = campos.get(i).split("\\|");

        if (camposLinha.length == 6 && !camposLinha[5].equals("null")) {
            String tempoSemMS = camposLinha[5].replace("ms", "");
            int tempo = Integer.parseInt(tempoSemMS);
            tempoTotal += tempo;
            cont++;
        }
    }

    if (cont == 0) {
        System.out.println("Não há dados suficientes para calcular a média");
        return 0;
    }

    return (double) tempoTotal / cont;
}
}
